from flask import Flask
from config import Config
from db import mongo
from routes.sentiment_route import sentiment_bp
from routes.user_route import user_bp
from routes.phq9_route import phq9_bp
from routes.history_route import history_bp
from routes.emotion_route import opencv_bp
from flask_cors import CORS 
from flask_socketio import SocketIO

app = Flask(__name__)
app.config.from_object(Config)
mongo.init_app(app)

CORS(app, origins=["http://localhost:5173"], supports_credentials=True) 

socketio = SocketIO(app, cors_allowed_origins=["http://localhost:5173"])

config = Config()
config.connect_mongodb()

app.register_blueprint(sentiment_bp)
app.register_blueprint(user_bp)
app.register_blueprint(phq9_bp)
app.register_blueprint(history_bp)
app.register_blueprint(opencv_bp) 

if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=5000) 
