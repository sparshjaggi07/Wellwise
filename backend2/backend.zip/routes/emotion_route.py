from flask import Blueprint, request, jsonify
from flask_socketio import SocketIO, emit
import cv2
import numpy as np
from deepface import DeepFace
import base64
from models.model_emotion import OpenCV
from db import mongo

opencv_bp = Blueprint('emotion', __name__) 
socketio = SocketIO()

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

emotion_counts = {
    'happy': 0,
    'sad': 0,
    'angry': 0,
    'fear': 0,
    'surprise': 0,
    'disgust': 0,
    'neutral': 0
}
frame_count = 0

@socketio.on('process_frame')
def process_frame(data):
    global frame_count, emotion_counts
    
    frame_data = data['frame']
    frame_bytes = base64.b64decode(frame_data.split(',')[1])
    frame_array = np.frombuffer(frame_bytes, np.uint8)
    frame = cv2.imdecode(frame_array, cv2.IMREAD_COLOR)

    gray_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rgb_frame = cv2.cvtColor(gray_frame, cv2.COLOR_GRAY2RGB)

    faces = face_cascade.detectMultiScale(gray_frame, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
    response = {'faces': []}

    for (x, y, w, h) in faces:
        face_roi = rgb_frame[y:y + h, x:x + w]
        
        # Using try-except to handle potential errors during emotion detection
        try:
            result = DeepFace.analyze(face_roi, actions=['emotion'], enforce_detection=False)
            emotion = result[0]['dominant_emotion']
        except Exception as e:
            emotion = 'unknown'  # If any error occurs, set emotion to 'unknown'

        response['faces'].append({
            'x': int(x),
            'y': int(y),
            'width': int(w),
            'height': int(h),
            'emotion': emotion
        })

        if emotion in emotion_counts:
            emotion_counts[emotion] += 1

    frame_count += 1
    emit('emotions_detected', response)



@socketio.on('end_session')
def end_session(user_id):
    global frame_count, emotion_counts

    opencv_data = {
        'happy': emotion_counts['happy'],
        'sad': emotion_counts['sad'],
        'fear': emotion_counts['fear'],
        'angry': emotion_counts['angry'],
        'surprise': emotion_counts['surprise'],
        'disgust': emotion_counts['disgust']
    }

    existing_data = OpenCV.get(user_id)
    if existing_data:
        OpenCV.update(user_id, opencv_data)
    else:
        OpenCV.create(user_id, **opencv_data)

    frame_count = 0
    emotion_counts = {emotion: 0 for emotion in emotion_counts}
    
    emit('session_ended', {'message': 'Session ended and data saved.'})
